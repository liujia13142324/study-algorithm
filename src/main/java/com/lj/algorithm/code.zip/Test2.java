package com.lj.algorithm;

import lombok.Data;
import lombok.SneakyThrows;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

/**
 *  获取多种支付方式
 */
public class Test2 {
    
    static PaymentRemoteService paymentRemoteService;
    
    public static void main(String[] args) {
    
        String[] payType = new String[]{"fee", "bank card", "alipay", "wechat"};
    
        CompletableFuture<ConsultResult>[] completableFutures = new CompletableFuture[payType.length];
        
        for (int i = 0; i < payType.length; i++) {
            int finalI = i;
            // 并发起 remote 请求
            completableFutures[i] = CompletableFuture.supplyAsync(() -> paymentRemoteService.isEnable(payType[finalI]));
        }
        
        // 所有的 future 全部拿到结果
        CompletableFuture.allOf(completableFutures).thenAcceptAsync(new Consumer<Void>() {
            @SneakyThrows
            @Override
            public void accept(Void aVoid) {
                // 根据返回结果，组装支持的支付方式
                List<String> supportedPayment = new ArrayList<>();
                for (int i = 0; i < completableFutures.length; i++) {
                    if (completableFutures[i].get().isEnable()) {
                        supportedPayment.add(payType[i]);
                    }
                }
            }
        });
    }
    
    
    public interface PaymentRemoteService{
        ConsultResult isEnable(String paymentType);
        // 如果是异步通信，应该要提供回调句柄，性能更好
        // void isEnable(String paymentType, Processor<ConsultResult> callback);
    }
    
    @Data
    public static class ConsultResult{
        /**
         * 咨询结果是否可用
         */
        private boolean isEnable;
        private String errorCode;
    }
    
    
  
    
}
